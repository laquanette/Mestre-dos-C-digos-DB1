| ![](.\Imagens\Logo_DB1.png) | Requisito - Administração e Criação de Provas | ![](.\Imagens\Logo_Prova.png) |
| :-------------------------: | :-------------------------------------------: | :---------------------------: |
|       **ID Req:** 002       |          **ID Projeto:** API_Provas           | **Nome Projeto:** Provas DB1  |



# Sumário

[TOC]

#  Informações


## Lista de Artefatos Relacionados

| Artefatos                             | Título                                           |
| :------------------------------------ | :----------------------------------------------- |
| Requisito Funcional - Provas          | [RF Provas.md](.\RF_Provas.md)                   |
| Requisito Funcional - Provas Questões | [RF Provas Questões.md](.\RF_Provas_Questoes.md) |
| Requisito Funcional - Provas View     | [RF Provas View.md](.\RF_Provas_View.md)         |



# Análise de Processos

Atualmente colaboradores do grupo DB1 Global Software que necessitam da criação e manipulação de provas para serem aplicadas em processos diversos, acabam sendo obrigados a procurar sistemas externos que possam satisfazer suas necessidades.

Sistemas externos exigem licenças pagas e possuem limitações nas funcionalidades de edição, administração e integração com *software* CRM/ERP utilizados na DB1.

Visando a resolução dos problemas mencionados acima, este projeto tem como objetivo o desenvolvimento da funcionalidade Banco de Provas, onde colaboradores poderão criar, editar e visualizar suas provas de maneira simples, ágil e totalmente online.



**Fluxograma:**

![](.\Imagens\Fluxograma_Provas_Provas.png)




## Premissa

- O usuário deverá logar com suas credenciais através do AD (Active Directory DB1) para que seja validado seu acesso e permissões;
- O usuário deverá pertencer ao grupo de colaboradores DB1 Global Software;
- Ter desenvolvido a área do sistema referente ao requisito [RF_Provas](./RF_Provas.md);



## Restrições

*não se aplica*




# História de Usuário

Como membro do departamento de recursos humanos da DB1 Global Software, desejo criar provas de maneira online com a opção de escolher tipos de questões diferentes e utiliza-las no processo de recrutamento e seleção.





#  Requisitos Funcionais

**Contexto da Rotina**: Conforme descrito em [Análise de Processos](#Análise de Processos), esta funcionalidade tem como objetivo a criação, edição e manipulação de provas, documentos que serão armazenados em um banco de provas para posterior utilização em processos diversos dentro da instituição.

**Atividades:**

- [Header](#Header)
- [Filtros](#Filtros)
- [Banco de Provas](#Banco de Provas)
- [Nova Prova](#Nova Prova)
- [Geração de Provas](#Geração de Provas)
- [Ícones tabela Banco de Provas](#Ícones tabela Banco de Provas)

Os protótipos mencionados neste documento estarão disponíveis através do link: [API_Provas Figma](https://www.figma.com/proto/Yg91UByoYkPUz8KzRN7E9C/API_Provas?node-id=886%3A16&viewport=144%2C795%2C0.17829525470733643&scaling=scale-down-width)



## Header

Tópico destinado ao cabeçalho do *software* de Provas, local onde o usuário terá as opções de navegar entre abas para executar as ações desejadas.

*A contextualização sobre este item encontra-se no requisito* [RF Provas.md](.\RF Provas.md)



## Filtros

O sistema deverá disponibilizar os campos informados neste tópico para que o usuário seja capaz de personalizar suas buscas de forma eficiente, seguem detalhes:

+ O filtro será aplicado na tabela [Banco de Provas](#Banco de Provas).
+ Imagem de exemplo dos campos:

![](.\Imagens\Provas_Filtro_01.jpg)



Tabela com detalhes dos campos acima:

| Núm  | Campo                                | Tipo           |             | Observação                                                  |
| :--: | :----------------------------------- | :------------- | :---------: | ----------------------------------------------------------- |
|  01  | Informe o código da prova...         | Número         |      -      | Campo para inserção do código.                              |
|  02  | Selecione a(s) tag(s) da prova...    | Combobox Multi | [RN1](#RN1) | Campo para seleção de tag. Favor consultar regras.          |
|  03  | Informe o nome da prova...           | Text           |      -      | Campo para inserção do nome.                                |
|  04  | Palavras Chaves...                   | Texto          |      -      | Campo para inserção de texto.                               |
|  05  | Selecione o departamento da prova... | Dropdown       | [RN1](#RN1) | Campo para seleção do departamento. Favor consultar regras. |
|  06  | Limpar Filtro                        | Button         | [RN2](#RN2) | Botão para limpar os filtros. Favor consultar regras.       |
|  07  | Aplicar                              | Button         | [RN3](#RN3) | Botão Aplicar. Favor consultar regras.                      |



Menu Reduzido:

![](.\Imagens\Questao_Filtro_02.jpg)



## Banco de Provas

Tópico destinado ao detalhamento dos itens pertencentes a tabela Banco de Provas.

![](.\Imagens\Provas_Banco_01.jpg)



Tabela com detalhes dos campos acima:

| Núm  | Campo           | Tipo       |     RN      | Observação                                                   |
| :--: | :-------------- | :--------- | :---------: | ------------------------------------------------------------ |
|  01  | Banco de Provas | Text       |      -      | Título da tabela.                                            |
|  02  | Tabela          | Table      | [RN4](#RN4) | Lista de provas existentes em banco. Favor consultar regras. |
|  03  | Nova Prova      | Button     |      -      | Adicionar uma nova prova. Mais detalhes em [Nova Prova](#Nova Prova). |
|  04  | Ícones          | Button     |      -      | Ícones para ações disponíveis. Mais detalhes em [Ícones tabela Banco de Provas](#Ícones tabela Banco de Provas). |
|  05  | Paginação       | Pagination |      -      | Paginação da tabela. Opção de selecionar a quantidade de linhas a serem exibidas. |



Visualização da tabela Banco de Provas sem registros:

![](.\Imagens\Provas_Banco_Vazio.jpg)



### Nova Prova

O sistema deverá disponibilizar o botão Nova Prova para que seja possível a geração de novos registros no banco de provas.

![](.\Imagens\Provas_Nova.png)



Tabela  com detalhes dos campos acima:

| Núm  | Campo                                | Tipo           | Obrig. |     RN      | Observação                                                   |
| :--: | :----------------------------------- | :------------- | :----: | :---------: | ------------------------------------------------------------ |
|  01  | Nova Prova                           | text           |   -    |      -      | Título do modal.                                             |
|  02  | Informe o nome da prova...           | Text           |  Sim   |      -      | Nome da prova. Máximo de 100 caracteres.                     |
|  03  | Selecione o departamento da prova... | Dropdown       |  Sim   | [RN1](#RN1) | -                                                            |
|  04  | Selecione a(s) tag(s) da prova...    | Dropdown Multi |   -    | [RN1](#RN1) | -                                                            |
|  05  | Informe o título da prova...         | text           |  Sim   |      -      | Título da prova exibido ao candidato. Máximo de 100 caracteres. |
|  06  | Cancelar                             | Button         |   -    |      -      | Cancelar a ação e voltar a tela [Banco de Provas](#Banco de Provas). |
|  07  | Avançar                              | Button         |   -    | [RN5](#RN5) | Botão Avançar. Favor consultar regras.                       |



### Geração de Provas

Página de geração das provas existentes no Banco de Provas, segue detalhes abaixo:

![](.\Imagens\Provas_Geracao.png)



Tabela com detalhes dos campos mencionados acima:

| Núm  | Campo           |   Tipo   |      RN       | Observação                                                   |
| :--: | --------------- | :------: | :-----------: | ------------------------------------------------------------ |
|  01  | Questões        |    -     | [RN19](#RN19) | Filtros e Banco de Questões. Vide regras.                    |
|  02  | Checkbox        | Checkbox |       -       | Campo para seleção de questões. Por ***default*** exibir *checkbox* vazio. |
|  03  | Preview Questão |  Button  |  [RN6](#RN6)  | Visualização de preview da questão. Vide regras.             |
|  04  | Setas           |  Button  |  [RN7](#RN7)  | Setas para movimentação das questões. Vide regras.           |
|  05  | Título          |   Text   |       -       | Título da prova.                                             |
|  06  | Ordenação       |  Button  |  [RN8](#RN8)  | Ordenação das questões vinculadas a prova. Vide regras.      |
|  07  | Editar          |  Button  |  [RN9](#RN9)  | Editar uma questão da prova. Vide regras.                    |
|  08  | Peso            |  Input   | [RN10](#RN10) | Peso das questões vinculadas a prova. Vide regras.           |
|  09  | Voltar          |  Button  | [RN11](#RN11) | Voltar a tela [Nova Prova](#Nova Prova). Vide regras.        |
|  10  | Preview         |  Button  |       -       | Exibir preview da prova. Vide tópico [Preview](#Preview).    |
|  11  | Cancelar        |  Button  | [RN16](#RN16) | Exibir o modal para confirmação do cancelamento. Vide regras. |
|  12  | Salvar          |  Button  | [RN18](#RN18) | Salvar registro em banco de dados. Vide regras.              |



### Ícones tabela Banco de Provas

Tópico destinado ao detalhamento dos ícones disponibilizados na tabela [Banco de Provas](#Banco de Provas), opções com ações sobre os registros existentes em banco, segue exemplos abaixo:

+ [Preview](#Preview)
+ [Editar](#Editar)
+ [Ativar/Inativar](#Ativar/Inativar)
+ [Histórico](#Histórico)

Imagem de exemplo:

![](.\Imagens\Questao_Banco_02.jpg)



#### Preview

**Comportamentos:**

+ Tooltip no ícone: O sistema deverá exibir a mensagem "Preview".
+ Ao acionar o botão *Preview* o sistema deverá abrir a tela de visualização da prova conforme exemplo abaixo:

![](.\Imagens\Provas_Banco_Preview_01.png)

Ao acionar o botão **Voltar - (1)** o sistema deverá voltar uma questão. Caso seja a questão de número 1 o botão deverá ficar desabilitado.

Ao acionar o botão **Cancelar - (2)** o sistema deverá fechar o preview e voltar a tela anterior.

Ao acionar o botão **Próximo- (3)** o sistema deverá avançar uma questão. Caso seja a última questão existente na prova, o sistema deverá exibir o botão mencionado abaixo.

![](.\Imagens\Provas_Banco_Preview_02.png)

Ao acionar o botão **Finalizar Prova** o sistema deverá realizar algumas ações, são elas:

+ Validar campos obrigatórios;

+ Exibir o processo de [*loading*](#RN12) até que o formulário seja salvo em banco de dados;
+ Após finalização do item anterior, o sistema deverá exibir a mensagem [Finalizar Prova](#RN15);
+ Na sequência dos itens anteriores o sistema deverá desabilitar os botões existentes na tela;



#### Editar

**Comportamentos:**

+ Tooltip: O sistema deverá exibir a mensagem "Editar"
+ Ao acionar o botão Editar o sistema deverá exibir o modal de confirmação para que o usuário possa inserir o motivo da solicitação de edição da prova, segue exemplo abaixo:

![](.\Imagens\Provas_Banco_Editar_01.png)

Ao acionar o botão **Cancelar - (1)** o sistema deverá fechar o modal e voltar a tela [Banco de Provas](#Banco de Provas).

Ao acionar o botão **Avançar - (2)** o sistema deverá validar a existência de conteúdo no campo motivo e então seguir para a tela [Geração de Provas](#Geração de Provas) exibindo todos os dados já contidos no registro da prova, segue exemplo de tela:

![](.\Imagens\Provas_Banco_Editar_02.png)



#### Ativar/Inativar

Abaixo serão mencionados os comportamentos referente aos botões de Ativar/Inativar uma prova, seguem tratativas:

|             Botão              | Ação               | Status da Prova | Tooltip  | Link                  |
| :----------------------------: | ------------------ | --------------- | -------- | --------------------- |
|   ![](.\Imagens\Botão V.png)   | Ativar uma prova   | Inativo         | Ativar   | [Ativar](#Ativar)     |
| ![](.\Imagens SVG\Botão X.svg) | Inativar uma prova | Ativo           | Inativar | [Inativar](#Inativar) |



##### Ativar

Ao acionar o **Botão Ativar -  (V)**, o sistema deverá exibir o modal de confirmação para que o usuário possa inserir o motivo da solicitação de ativação da prova, segue exemplo abaixo:

![](.\Imagens\Provas_Banco_Ativo-Inativo_02.jpg)

Ao acionar o botão **Cancelar - (1)** o sistema deverá fechar o modal e voltar a tela [Banco de Provas](#Banco de Provas) sem realizar alterações no registro.

Ao acionar o botão **Salvar - (2)** o sistema deverá validar a existência de conteúdo no campo motivo e então realizar as ações a seguir:

+ Alterar status do registro para Ativo;
+ Alterar ícone de ação Ativar/Inativar para **Botão Inativar - (X)**;



##### Inativar

Ao acionar o **Botão Inativar -  (X)** o sistema deverá exibir o modal de confirmação para que o usuário possa inserir o motivo da inativação da prova, segue exemplo abaixo:

![](.\Imagens\Provas_Banco_Ativo-Inativo_01.jpg)

Ao acionar o botão **Cancelar - (1)** o sistema deverá fechar o modal e voltar a tela [Banco de Provas](#Banco de Provas) sem realizar alterações no registro.

Ao acionar o botão **Salvar - (2)** o sistema deverá validar a existência de conteúdo no campo motivo e então realizar as ações a seguir:

- Alterar status do registro para Inativo;
- Alterar ícone de ação Ativar/Inativar para **Botão Ativar - (V)**;



#### Histórico

**Comportamentos:**

- Tooltip: O sistema deverá exibir a mensagem "Histórico".
- Ao acionar o botão *Histórico* o sistema deverá exibir um modal com as informações contidas no registro da prova, segue imagem de exemplo:

![](.\Imagens\Provas_Banco_Historico_01.png)



Tabela com detalhes dos campos acima:

| Núm  | Campo      | Tipo      | Observação                                                   |
| :--: | :--------- | --------- | :----------------------------------------------------------- |
|  01  | Histórico  | Text      | Título do modal.                                             |
|  02  | X          | Button    | Fechar o modal e voltar a tela [Banco de Provas](#Banco de Provas). |
|  03  | Cabeçalho  | Text      | Informações a respeito da prova que está sendo consultada.   |
|  04  | Data       | Date      | Data e hora de alteração do registro.                        |
|  05  | Usuário    | Text      | Usuário que realizou a alteração no registro.                |
|  06  | Status     | Text      | Status do registro.                                          |
|  07  | Observação | Text      | Texto referente a observação inserida no momento de realizar uma alteração de status ou edição da prova. |
|  08  | Scroll     | Scrollbar | Utilização de scroll caso exista mais de 5 registros no histórico. |




## Regras de Negócios

### RN1
#### Opções Dropdown

Regra destinada a definição das opções que deverão ser exibidas nos menus *dropdown* existentes neste documento.

**Campos e opções disponíveis:**

+ `Selecione o departamento da questão...` : Recursos Humanos; Farol;

+ `Selecione a(s) tag(s) da questão...` :
    + Frontend (HTML, CSS, Javascript)
        Vue
        Angular
        React
        Android
        iOS
        React Native
        Java
        Delphi
        .NET
        PHP
        Banco de dados
        Português
        Matemática
        Inglês
        Raciocínio Lógico
        Fit Cultural
        Comportamental
        Outros




### RN2
#### Botão Limpar Filtro

O botão Limpar Filtro terá a ação de limpar o(s) filtro(s) solicitado(s), seguem observações quanto as regras de funcionamento:

+ O botão ficará disponível para acionamento apenas quando o usuário selecionar ou inserir informações nos campos de filtragem;
+ Limpar todos os filtros que tiverem em execução;
+ Limpar todos os campos que tiverem informações inseridas;



### RN3

#### Botão Aplicar Filtro

**Comportamentos e Funções:**

+ O botão deverá ficar desabilitado quando nenhum campo for preenchido ou selecionado;
+ Ao acionar o botão Aplicar o sistema deverá filtrar a tabela [Banco de Provas](#Banco de Provas) em busca dos filtros solicitados;
+ Ao acionar o botão o sistema deverá exibir um [*Loading*](#RN12) até que a ação seja concluída, evitando assim o acionamento sequencial;
+ Caso o filtro realizado não retorne informações, o sistema deverá exibir a tabela [Banco de Provas](#Banco de Provas) sem registros (Consultar o tópico mencionado anteriormente para apresentação de tabela sem conteúdo); 



### RN4

#### Tabela Banco de Provas

A tabela Banco de Provas deverá exibir todos os registros de provas existentes no banco, segue abaixo detalhes dos campos existentes.

| Campo        | Tipo   |  Mascara  | Observação                                                   |
| ------------ | ------ | :-------: | ------------------------------------------------------------ |
| Código       | Número | 5 dígitos | Código da Prova, campo com geração automática de número sequencial. |
| Data         | Date   | dd/mm/aa  | Data de registro da prova, mascara utilizada: dd/mm/aa.      |
| Nome         | Text   |     -     | Nome da prova.                                               |
| Departamento | Text   |     -     | Departamento que efetuou o registro da prova.                |
| Tag          | Tag    |     -     | Tag(s) referente ao registro.                                |
| Status       | Text   |     -     | Status da prova.                                             |



### RN5

#### Botão Avançar

**Comportamentos**:

- O botão Avançar por ***default*** será exibido em modo desabilitado, somente quando o usuário preencher todos os campos obrigatórios contidos no formulário de [Nova Prova](#Nova Prova) então o sistema deverá habilitar o botão para acionamento.
- Ao acionar o botão Avançar o sistema deverá exibir a tela de [*Loading*](#RN12) até que a tela [Geração de Provas](#Geração de Provas) seja carregada.



### RN6

#### Preview de Questão

Ao acionar o botão *preview* localizado na tabela Banco de Questões  que compõe a tela de [Geração de Provas](#Geração de Provas) o sistema deverá exibir um modal com as informações contidas no registro da questão.

**Comportamento:**

+ Tooltip: O sistema deverá exibir a mensagem "Preview".

Imagem de exemplo:

![](.\Imagens\Provas_Nova_Preview_Questao.png)



### RN7

#### Setas de transferência

Setas disponíveis na tela de [Geração de Provas](#Geração de Provas) para que o usuário possa transferir questões do Banco de Questões para a Prova ou vice versa, segue imagem de exemplo dos botões:

![](.\Imagens\Provas_Nova_Setas.jpg)

**Comportamentos:**

+ Botão Desabilitado: Por *default* deverá ficar desabilitado até que seja selecionado algum *checkbox* "Item 2 do tópico [Geração de Provas](#Geração de Provas)" pertencentes aos registros existentes nas tabelas;
+ Botão Habilitado: Quando um ou mais registros forem selecionados.

+ Seta Direita: Enviar para a prova os registros selecionadas na tabela Banco de Questões.
+ Seta Esquerda: Remover da prova os registros selecionados.



### RN8

#### Ordenação de questões

Botões disponíveis para que o usuário possa ordenar a lista de questões existentes na prova, segue imagem de exemplo:

![](.\Imagens\Provas_Nova_Ordenacao.jpg)

**Comportamentos:**

+ Botão Desabilitado: Por *default* deverá ficar desabilitado até que seja selecionado algum registro da lista de questões da prova.
+ Botão Habilitado: Quando um ou mais registros forem selecionados.
+ Movimentação de registros:
  + Mover para Cima: O sistema deverá mover o registro uma posição acima.
  + Mover para Baixo: O sistema deverá mover o registro uma posição abaixo.
  + Caso o primeiro registro esteja selecionado o sistema deverá desabilitar o botão de movimentação para Cima;
  + Caso o último registro esteja selecionado o sistema deverá desabilitar o botão de movimentação para Baixo;



### RN9

#### Editar Questão da Prova

Ao acionar o botão de edição da questão localizado na tela [Geração de Provas](#Geração de Provas), o sistema deverá exibir um modal para que o usuário possa escolher a opção desejada, segue exemplo abaixo:

![](.\Imagens\Provas_Nova_Editar_Questao_01.png)

**Comportamentos e Funções:**

+ **Texto - (1)**

```
Sua solicitação será realizada apenas na questão vinculada a esta prova, para alterar a questão padrão favor realizar procedimento no cadastro de questões.
```

+ Ao selecionar o botão **Não exibir mensagem novamente - (2)** o sistema deverá salvar essa escolha e não exibir a mensagem novamente para esse usuário.

+ Ao acionar o botão **Cancelar - (3)** o sistema deverá cancelar a ação e voltar a tela [Geração de Provas](#Geração de Provas).

+ Ao acionar o botão **Avançar - (4)** o sistema deverá direcionar o usuário a tela para edição da questão da prova, segue exemplo de imagem abaixo:

![](.\Imagens\Provas_Nova_Editar_Questao_02.png)

O título **Editar Questão da Prova** será a única alteração em relação a tela Nova Questão contida no arquivo [RF Provas Questões.md](.\RF_Provas_Questoes.md). Segue tratativas especificas com relação a edição de questões da prova:

+ O sistema deverá salvar as informações inseridas em banco de dados separado, pois cada prova terá suas próprias questões.
+ O campo Código da questão não será necessário para questões vinculadas a provas, pois elas terão seus próprios ID's.



### RN10

#### Peso das Questões

Campo disponível para inserção do valor referente ao peso da questão, podendo digitar o valor preestabelecido ou clicar nas setas cima/baixo até o valor desejado. Segue detalhes abaixo:

+ Por *default* o sistema deverá inserir peso "1" sempre que uma questão for adicionada a prova.
+ Opções disponíveis para seleção: números de 1 a 5 (1,2,3,4,5).
+ O valor selecionado deverá ser gravado junto ao registro da questão para posterior utilização em outras aplicações.



### RN11

#### Botão Voltar

**Comportamento:**

+ Ao acionar o botão Voltar o sistema deverá salvar as informações contidas na tela [Geração de Provas](#Geração de Provas) e então exibir o modal [Nova Prova](#Nova Prova).



### RN12

#### Loading

Esta regra é destinada ao comportamento e especificação do indicador de *loading* exibido quando uma ação é requisitada pelo sistema.

+ O indicador deverá ser exibido no topo da aplicação.

Sugestão de código para implementação: [Vuetify Loading](https://vuetifyjs.com/en/components/inputs#loading)

![](.\Imagens\Msg_Loading_01.jpg)



### RN13

#### Mensagem de Sucesso

Esta regra é destinada ao comportamento e especificação da mensagem de sucesso exibida quando um formulário é salvo no sistema.

+ A mensagem deverá ser exibida no topo da aplicação.

Exemplo:

![](.\Imagens\Msg_Success_01.jpg)



### RN14

#### Erro de Servidor

Regra destinada ao comportamento e especificação da mensagem de erro exibida quando uma ação é interrompida no sistema por problemas com servidor.

- A mensagem deverá ser exibida no topo da página.

Exemplo:

![](.\Imagens\Msg_Error_01.jpg)



### RN15

#### Finalizar Prova

Regra destinada a exibição da mensagem de sucesso após a finalização de uma prova no sistema.

- A mensagem deverá ser exibida no topo da aplicação.

Exemplo:

![](.\Imagens\Msg_Success_02.png)



### RN16

#### Botão *Cancelar* Geração de Provas

O botão Cancelar existente na tela Geração de Provas terá a função de exibir o modal para confirmação do cancelamento de geração de prova, segue detalhes abaixo:

+ Ao acionar o botão Cancelar o sistema deverá exibir o modal abaixo:

![](.\Imagens\Modal Aviso.png)

Ao acionar o botão **Cancelar - (1)** o sistema deverá fechar o modal e voltar a tela Geração de Provas.

Ao acionar o botão **Sim - (2)** o sistema deverá ignorar as informações inseridas no formulário e exibir a tela [Banco de Provas](#Banco de Provas).



### RN17

#### Tecla ESQ

O objetivo dessa regra de negócio é definir a tecla ESQ como sendo um atalho para o fechamentos dos modais existentes neste documento, onde deverá seguir os seguintes comportamentos:

**Comportamentos:**

+ Ao acionar a tecla ESQ o sistema deverá fechar o modal e direcionar o usuário a tela anterior;
+ O sistema deverá fechar o modal e não realizar alterações no formulário;



### RN18

#### Botão *Salvar* Geração de Provas

Ao acionar o botão Salvar contido na página Geração de Provas o sistema deverá realizar os seguintes comportamentos:

+ Validar a existência de no mínimo 01 questão inserida na tabela de questões da prova;
+ Exibir a tela de [*Loading*](#RN12) até que o formulário seja processado e salvo em banco de dados;
+ Exibir a [Mensagem de Sucesso](#RN13) após o processamento do item anterior;



### RN19

#### Filtros e Banco de Questões

Regra destinada a especificação dos campos pertencentes as questões disponíveis na Geração de Provas, segue detalhes abaixo:

**Filtros**:
+ O sistema deverá buscar informações para a aplicação dos filtros na tabela de Banco de Questões;



**Tabela Banco de Questões:**

+ O sistema deverá carregar as informações exibidas na tabela Banco de Questões contidas no documento disponível abaixo;
+ O sistema deverá carregar somente as questões com status ATIVO;



*Documento de apoio:* [RF_Provas_Questoes.md](.\RF_Provas_Questoes.md)



# Testes de Aceitação do Usuário

## Critério de Aceitação

O sistema será considerado como concluído somente após a validação e aprovação dos tópicos mencionados acima, é de extrema importância a realização dos itens a seguir:

- Seguir os padrões de layout especificados neste documento;
- Seguir a disposição dos objetos conforme mencionados nos tópicos acima, visto que os padrões de usabilidade seguem boas práticas de mercado;



### Cenários

+ Geração de provas:

**Dado** que eu esteja na página [Geração de Provas](#Geração de Provas) 
​		E eu preencha os dados para uma nova prova
**Quando** eu acionar o botão Voltar,
**Então** deverá armazenar os dados contidos no formulário atual e exibir o modal [Nova Prova](#Nova Prova).



+  Efetuar alteração de Título:

**Dado** que eu esteja na página [Geração de Provas](#Geração de Provas),
E eu acione o botão Voltar
**Quando** exibir o modal [Nova Prova](#Nova Prova),
		E eu efetuar alteração no título da prova
		E acionar o botão Avançar
**Então** deverá exibir a página [Geração de Provas](#Geração de Provas) com os dados atualizados.



+ Cancelar alterações de prova:

**Dado** que eu esteja na página [Geração de Provas](#Geração de Provas),
		E eu acione o botão Voltar
**Quando** exibir o modal [Nova Prova](#Nova Prova),
		E eu efetuar alterações
		E acionar o botão Cancelar
**Então** deverá ignorar alterações e exibir a página [Banco de Provas](#Banco de Provas).



+ Acionar o botão Salvar no modal Ativar/Inativar uma Prova

**Dado** que eu esteja na tela [Banco de Provas](#Banco de Provas)
		E acione o botão para [Ativar/Inativar](#Ativar/Inativar) uma prova
		E adicione um motivo no modal que será exibido
**Quando** eu acionar o botão Cancelar pertencente ao modal,
**Então** deverá ignorar alterações realizadas e fechar o modal.



+ Acionar o botão Cancelar no modal Ativar/Inativar uma Prova

**Dado** que eu esteja na tela [Banco de Provas](#Banco de Provas)
		E acione o botão para [Ativar/Inativar](#Ativar/Inativar) uma prova
		E adicione um motivo no modal que será exibido
**Quando** eu acionar o botão Salvar pertencente ao modal,
**Então** deverá alterar o registro e fechar o modal.



+ Editar uma Prova

**Dado** que eu esteja na tela [Banco de Provas](#Banco de Provas)
		E acione o botão para editar uma prova
**Quando** o modal [Editar](#Editar) for exibido
		E eu inserir o motivo
		E acionar o botão Avançar
**Então** deverá exibir a tela [Geração de Provas](#Geração de Provas) com as informações correspondentes da prova selecionada para edição.




# Termo de Compromisso

Estou ciente que todas as implementações citadas neste  documento estão condizentes com a necessidade da empresa, sendo assim,  reconheço que futuras alterações de assuntos não mencionados neste documento  serão consideradas como uma nova alteração não prevista, gerando uma nova  análise e levantamento, bem como a descrição de um novo documento de  Especificação de Requisito.

 

I am aware  that all implementations mentioned in this document are consistent with the  company's need, so that future changes to recognize issues not listed in this  document will be considered as a new change not provided, generating a new  survey and analysis, as well as the description of a new Requirement  Specification document.



# Aprovação

Data limite de aprovação segundo o plano de projeto: **[Data Limite]**

| Nome          | Data | Assinatura |
| ------------- | ---- | ---------- |
| Cristiane Abe |      |            |