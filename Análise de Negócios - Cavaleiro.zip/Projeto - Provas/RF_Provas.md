| ![](.\Imagens\Logo_DB1.png) | Requisito - Aplicação Test | ![](.\Imagens\Logo_Prova.png) |
| :-------------------------: | :------------------------: | :---------------------------: |
|       **ID Req:** 001| **ID Projeto:** API_Provas | **Nome Projeto:** Provas DB1  |



# Sumário

[TOC]

#  Informações

## Edições

| Número |   Data   | Autor             | Comentários                     |
| :----: | :------: | ----------------- | ------------------------------- |
|  1.0   | 30/08/19 | Renato Laquanette | Criação do Documento            |
|  1.1   | 04/10/19 | Renato Laquanette | Atualização de Regras e Padrões |
|  1.2   | 27/11/19 | Renato Laquanette | Atualização de layout DB1 Group |






## Lista de Artefatos Relacionados

| Artefatos                        | Título                                           |
| :------------------------------- | :----------------------------------------------- |
| Requisito - Geração de Questões  | [RF_Provas Questoes.md](.\RF_Provas_Questoes.md) |
| Requisito - Geração de Provas    | [RF_Provas Provas.md](.\RF_Provas_Provas.md)     |
| Requisito - View de Provas       | [RF_Provas_View.md](.\RF_Provas_View.md)         |
| Não Funcional - Funcional        | [RN_Funcional.md](./RN_Funcional.md)             |
| Não Funcional - Interface Padrão | [RN_InterfacePadrao.md](./RN_InterfacePadrao.md) |





# Análise de Processos

Atualmente colaboradores que necessitam criar provas para realizar processos seletivos ou apenas documentos de pesquisas, como formulários ou questionários são forçados a procurar sistemas externos para tal resolução.

Sistemas externos exigem licenças pagas e possuem limitações nas funcionalidades de edição, administração e integração com *software* CRM/ERP utilizados na DB1 Global Software.

Visando a resolução dos problemas mencionados acima, este projeto tem como objetivo o desenvolvimento do sistema de Provas, onde colaboradores poderão criar e gerenciar suas avaliações de forma simples e ágil.



**Fluxograma**

![](.\Imagens\Fluxograma Provas.png)



## Premissa

- **Autenticação**
  - O usuário deverá logar com suas credenciais através do AD (Active Directory DB1) para que seja validado seu acesso e permissões;
- **Acesso**
  - O usuário deverá pertencer ao grupo de colaboradores DB1 Global Software;



## Restrições

*não se aplica*




# História de Usuário

Como membro do departamento de Recursos Humanos da DB1 Global Software, desejo criar provas e questões personalizadas, automatizar vagas de recrutamento e seleção e corrigir as provas encaminhadas na automatização de maneira online.





#  Requisitos Funcionais

**Contexto da Rotina**: Conforme descrito em [Análise de Processos](#Análise de Processos), esta funcionalidade contempla os itens abaixo:

+ [Header](#Header);
+ [Home](#Home);
+ [Administração de Questões](#Questões);
+ [Administração de Provas](#Provas);



**Protótipos**:

+  Os protótipos mencionados neste documento estarão disponíveis pelo link: [API_Provas Figma](https://www.figma.com/proto/Yg91UByoYkPUz8KzRN7E9C/API_Provas?node-id=886%3A16&viewport=144%2C795%2C0.17829525470733643&scaling=scale-down-width)



## Header

Tópico destinado ao cabeçalho do *software* de Provas, abaixo serão mencionados as opções disponíveis para que o usuário possa realizar ações a respeito da criação, edição e administração de provas.



![](.\Imagens\Header.png)



+ **Logo DB1 Group :** Ao acionar o botão o sistema deverá direcionar o usuário para a página da DB1 Group. "http://www.db1group.com"
+ **Home :** Ao acionar o botão o sistema deverá direcionar o usuário para a página principal da aplicação, mais detalhes em [Home](#Home).
+  **Questões :** Ao acionar o botão o sistema deverá direcionar o usuário para a página de questões conforme descrito em [Questões](#Questões).
+ **Provas :** Ao acionar o botão o sistema deverá direcionar o usuário para a página de provas conforme descrito em [Provas](#Provas).
+ O item **Usuário - (5)** deverá exibir informações a respeito do usuário que estará utilizando o sistema.
  + Informações:
    + Nome e sobrenome;
    + Avatar com foto;
  + O sistema deverá buscar as informações mencionadas acima no AD (Active Directory DB1);



## Home

*A Definir*



## Questões

A opção Questões existente no header deste projeto deverá direcionar o usuário a página de administração das questões existentes em banco de dados, segue itens pertencentes a tela:

+ **Funcionalidades**:
  + Filtros
  + Banco de Questões
  + Nova Questão
  + Peso Alternativa
  + Tipo Questão
  + Preview de Modelo

*A contextualização sobre cada um destes itens encontra-se no requisito* [RF Provas Questoes.md](.\RF_Provas_Questoes.md).



## Provas

A opção Provas existente no header deste projeto deverá direcionar o usuário a página de administração das provas existentes em banco de dados, segue itens pertencentes a tela:

+ **Funcionalidades**:
  + Filtros
  + Banco de Provas
  + Nova Prova
  + Preview de modelo da prova

*A contextualização sobre cada um destes itens encontra-se no requisito* [RF Provas Provas.md](.\RF_Provas_Provas.md).




## Regras de Negócios

### RN1
#### Erro de Servidor

Este tópico descreve a forma de apresentação caso algum erro inesperado com o serviço de envio ao servidor ocorra. 

- A mensagem deverá ser exibida no topo da página.

Imagem de exemplo:

![](.\imagens\Msg_Error_01.jpg)



# Testes de Aceitação do Usuário

## Critério de Aceitação

O sistema será considerado como concluído somente após a validação e aprovação dos tópicos mencionados acima, é de extrema importância a realização dos itens a seguir:

+ O sistema deverá seguir os padrões de layout especificado neste documento;
+ O sistema deverá seguir a disposição dos objetos conforme mencionados nos tópicos acima, visto que os padrões de usabilidade seguem boas práticas de mercado;
+ O sistema deverá disponibilizar o acesso web a ferramenta;
+ O sistema deverá disponibilizar os menus superiores para navegação na ferramenta;



## Cenários

Cenário 01 - Acesso a funcionalidade

**Dado** que eu tenha efetuado login com minhas credenciais
**Quando** eu acionar o botão Questões no menu superior
**Então** o sistema deverá me direcionar a tela com a listagem das questões existentes em banco de dados.



Cenário 02 - Erro de conexão

**Dado** que eu tenha efetuado login com minhas credenciais
**Quando** eu acionar o botão Questões no menu superior
   **E** venha ocorrer perda de conexão com o servidor,
**Então** o sistema deverá exibir a Mensagem de Alerta contida na [RN1](#RN1).




# Termo de Compromisso

Estou ciente que todas as implementações citadas neste  documento estão condizentes com a necessidade da empresa, sendo assim,  reconheço que futuras alterações de assuntos não mencionados neste documento  serão consideradas como uma nova alteração não prevista, gerando uma nova  análise e levantamento, bem como a descrição de um novo documento de  Especificação de Requisito.

 

I am aware  that all implementations mentioned in this document are consistent with the  company's need, so that future changes to recognize issues not listed in this  document will be considered as a new change not provided, generating a new  survey and analysis, as well as the description of a new Requirement  Specification document.



# Aprovação

Data limite de aprovação segundo o plano de projeto: **[Data Limite]**

| Nome          | Data | Assinatura |
| ------------- | ---- | ---------- |
| Cristiane Abe |      |            |