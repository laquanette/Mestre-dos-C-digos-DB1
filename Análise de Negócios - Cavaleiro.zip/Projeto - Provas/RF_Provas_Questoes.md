| ![](.\Imagens\Logo_DB1.png) | Requisito - Administração e Criação de Questões | ![](.\Imagens\Logo_Prova.png) |
| :-------------------------: | :---------------------------------------------: | :---------------------------: |
|       **ID Req:** 003       |           **ID Projeto:** API_Provas            | **Nome Projeto:** Provas DB1  |



# Sumário

[TOC]

#  Informações


## Lista de Artefatos Relacionados

| Artefatos                               | Título                                       |
| :-------------------------------------- | :------------------------------------------- |
| Requisito Funcional - Projeto Provas    | [RF_Provas.md](.\RF_Provas.md)               |
| Requisito Funcional - Geração de Provas | [RF_Provas_Provas.md](.\RF_Provas_Provas.md) |
| Requisito Funcional - Provas View       | [RF_Provas_View.md](.\RF_Provas_View.md)     |



# Análise de Processos

Atualmente colaboradores que necessitam da criação e manipulação de provas para serem aplicadas em processos diversos, acabam sendo obrigados a procurarem sistemas externos que possam satisfazer suas necessidades.

Sistemas externos exigem licenças pagas e possuem limitações nas funcionalidades de edição, administração e integração com *software* CRM/ERP utilizados na DB1 Global Software.

Visando a resolução dos problemas mencionados acima, este projeto tem como objetivo o desenvolvimento da funcionalidade Banco de Questões, onde colaboradores poderão criar e gerenciar suas questões de forma simples e ágil.



**Fluxograma:**

![](.\Imagens\Fluxograma_Provas_Questoes.png)




## Premissa

- O usuário deverá logar com suas credenciais através do AD (Active Directory DB1) para que seja validado seu acesso e permissões;
- O usuário deverá pertencer ao grupo de colaboradores DB1 Global Software;
- Ter desenvolvido a área do sistema referente ao requisito [RF_Provas](./RF_Provas.md);
- Ter desenvolvido a área do sistema referente ao requisito [RF_Provas_Provas](./RF_Provas_Provas.md);



## Restrições

*não se aplica*




# História de Usuário

Como membro do departamento de recursos humanos da DB1 Global Software, desejo criar questões de diferentes tipos para que eu possa utiliza-las na confecção de provas que serão aplicadas no processo de recrutamento e seleção.



#  Requisitos Funcionais

**Contexto da Rotina**: Conforme descrito em [Análise de Processos](#Análise de Processos), esta funcionalidade tem como objetivo a criação e manipulação de questões, objetos que serão armazenados em um banco de questões para posterior utilização na criação de uma avaliação.

Atividades:

+ [Header](#Header)
+ [Filtros](#Filtros)
+ [Banco de Questões](#Banco de Questões)
+ [Nova Questão](#Nova Questão)
+ [Tipos de Questões](#Tipos de Questões)
+ [Ícones tabela Banco de Questões](#Ícones tabela Banco de Questões)

Os protótipos mencionados neste documento estarão disponíveis através do link: [API_Provas Figma](https://www.figma.com/proto/Yg91UByoYkPUz8KzRN7E9C/API_Provas?node-id=886%3A16&viewport=144%2C795%2C0.17829525470733643&scaling=scale-down-width)



## Header

Tópico destinado ao cabeçalho do *software* de Provas, local onde o usuário terá as opções de navegar entre abas para executar as ações desejadas.

*A contextualização sobre este item encontra-se no requisito* [RF Provas.md](.\RF_Provas.md).



## Filtros

O sistema deverá disponibilizar os campos informados neste tópico para que o usuário seja capaz de filtrar suas buscas de forma eficiente, seguem detalhes:

**Observação**: O sistema deverá utilizar os dados da tabela [Banco de Questões](#Banco de Questões) para a busca das informações.



![](.\Imagens\Questao_Filtro_01.jpg)



Tabela com detalhes dos campos acima:

| Núm  | Campo                                  | Tipo           |             | Observação                                                   |
| :--: | :------------------------------------- | :------------- | :---------: | ------------------------------------------------------------ |
|  01  | Filtros                                | Text           |      -      | Título da tabela de filtros.                                 |
|  02  | Informe o código da questão...         | Número         |      -      | Campo para inserção do código.                               |
|  03  | Informe o nome da questão...           | Text           |      -      | Campo para inserção do nome.                                 |
|  04  | Selecione o departamento da questão... | Dropdown       | [RN1](#RN1) | Campo para seleção do departamento. Favor consultar regras.  |
|  05  | Selecione o tipo da questão...         | Dropdown       | [RN1](#RN1) | Campo para seleção do tipo. Favor consultar regras.          |
|  06  | Selecione a(s) tag(s) da questão...    | Combobox Multi | [RN1](#RN1) | Campo para seleção de tag. Favor consultar regras.           |
|  07  | Selecione o nível da questão...        | Dropdown       | [RN1](#RN1) | Campo para seleção do nível de dificuldade. Favor consultar regras. |
|  08  | Palavras Chaves...                     | Texto          |      -      | Campo para inserção de texto.                                |
|  09  | Limpar Filtro                          | Button         | [RN2](#RN2) | Botão para limpar os filtros. Favor consultar regras.        |
|  10  | Aplicar                                | Button         | [RN3](#RN3) | Botão Aplicar. Favor consultar regras.                       |



Menu Reduzido:

![](.\Imagens\Questao_Filtro_02.jpg)



## Banco de Questões

Tópico destinado ao detalhamento dos itens pertencentes a tabela Banco de Questões.

![](.\Imagens\Questao_Banco_01.jpg)



Tabela com detalhes dos campos acima:

| Núm  | Campo             | Tipo       |     RN      | Observação                                                   |
| :--: | :---------------- | :--------- | :---------: | ------------------------------------------------------------ |
|  01  | Banco de Questões | Text       |      -      | Título da tabela.                                            |
|  02  | Tabela            | Table      | [RN4](#RN4) | Lista de questões existentes em banco. Favor consultar regras. |
|  03  | Nova Questão      | Button     |      -      | Adicionar uma nova questão. Mais detalhes em [Nova Questão](#Nova Questão). |
|  04  | Ícones            | Button     |      -      | Ícones para ações disponíveis. Mais detalhes em [Ícones tabela Banco de Questões](#Ícones tabela Banco de Questões). |
|  05  | Paginação         | Pagination |      -      | Paginação da tabela. Opção de selecionar a quantidade de linhas a serem exibidas. |



Visualização da tabela Banco de Questões sem registros:

![](.\Imagens\Questao_Banco_Vazio.jpg)



### Nova Questão

Para que o usuário tenham itens em seu banco de questões, o sistema deverá disponibilizar as configurações de inserção conforme especificações abaixo:



![](.\Imagens\Questao_Nova.jpg)



Tabela  com detalhes dos campos acima:

| Núm  | Campo                                  | Tipo           | Obrig. |       RN       | Observação                                       |
| :--: | :------------------------------------- | :------------- | :----: | :------------: | ------------------------------------------------ |
|  01  | Selecione o departamento da questão... | Dropdown       |  Sim   |  [RN1](#RN1)   | -                                                |
|  02  | Selecione o tipo da questão...         | Dropdown       |  Sim   |  [RN1](#RN1)   | -                                                |
|  03  | Selecione a(s) tag(s) da questão...    | Dropdown Multi |   -    |  [RN1](#RN1)   | -                                                |
|  04  | Selecione o nível da questão...        | Dropdown       |  Sim   |  [RN1](#RN1)   | -                                                |
|  05  | Informe o nome da questão...           | Text           |  Sim   |       -        | Nome da questão. Máximo de 100 caracteres.       |
|  06  | Habilitar campo para justificativa     | Checkbox       |   -    | [RN14](# RN14) | Opção para adicionar justificativa.              |
|  07  | Voltar                                 | Button         |   -    | [RN15](#RN15)  | Exibir o modal para confirmação, vide regras.    |
|  08  | Preview                                | Button         |   -    |  [RN5](#RN5)   | Preview de Nova Questão. Favor consultar regras. |
|  09  | Salvar                                 | Button         |   -    |  [RN6](#RN6)   | Botão Salvar. Favor consultar regras.            |



#### Tipos de Questões

O sistema de provas deverá disponibilizar algumas opções para que o usuário possa escolher os tipos de questões que atenda sua necessidade, segue detalhes:

Fluxograma do processo:

![](.\Imagens\Fluxograma_Provas_Questoes_Tipos.png)

##### Múltipla Escolha

Imagem de exemplo:

![](.\Imagens\Questao_Nova_Multipla_01.jpg)



Tabela com informações sobre os campos acima:

| Núm  | Campo                      | Tipo   |     RN      | Observação                                                   |
| :--: | -------------------------- | ------ | :---------: | ------------------------------------------------------------ |
|  01  | Enunciado                  | Text   |      -      | Campo de inserção do enunciado da questão. Limitar em 10.000 caracteres. |
|  02  | Digite seu texto aqui...   | Text   |      -      | Campo para inserção do texto referente a alternativa.        |
|  03  | Adicionar nova alternativa | Button | [RN7](#RN7) | Adicionar novas alternativas. Favor consultar regras.        |
|  04  | Correta/Errada             | Button | [RN8](#RN8) | Definir valor Correta/Errada para alternativa. Favor consultar regras. |
|  05  | Excluir                    | Button | [RN9](#RN9) | Excluir alternativa. Favor consultar regras.                 |
| 06 | Selecione o peso da alternativa | Input | [RN10](#RN10) | Selecionar o peso da alternativa |



##### Seleção Única

Imagem de exemplo:

![](.\Imagens\Questao_Nova_Unica_01.jpg)

Tabela com informações sobre os campos acima:

| Núm  | Campo                      | Tipo   |     RN      | Observação                                                   |
| :--: | -------------------------- | ------ | :---------: | ------------------------------------------------------------ |
|  01  | Enunciado                  | Text   |      -      | Campo de inserção do enunciado da questão. Limitar em 5.000 caracteres. |
|  02  | Digite seu texto aqui...   | Text   |      -      | Campo para inserção do texto referente a alternativa.        |
|  03  | Adicionar nova alternativa | Button | [RN7](#RN7) | Adicionar novas alternativas. Favor consultar regras.        |
|  04  | Correta/Errada             | Button | [RN8](#RN8) | Definir valor Correta/Errada para alternativa. Favor consultar regras. |
|  05  | Excluir                    | Button | [RN9](#RN9) | Excluir alternativa. Favor consultar regras.                 |




##### Justificativa

Exemplo de opção com Justificativa:

![](.\Imagens\Questao_Nova_Justificativa_01.jpg)

+ **Observações:**
  + O campo justificativa deverá ser exibido apenas quando o candidato for responder a prova, não sendo necessário a apresentação para o usuário desenvolvedor da questão.
  + A resposta do campo em questão será obrigatória.



##### Dissertativa

O sistema deverá disponibilizar um campo *textareas* para que o usuário possa inserir as informações referentes ao enunciado da questão.

Sugestão de código para implementação:[Vuetify Textareas](https://vuetifyjs.com/en/components/textarea)

![](.\Imagens\Questao_Nova_Dissertativa_01.jpg)

+ O sistema deverá limitar o campo texto em 10.000 caracteres.



##### Associativa

*A Definir*

##### Numérica

*A Definir*

##### Verdadeiro/Falso

*A Definir*



### Ícones tabela Banco de Questões

Tópico destinado ao detalhamento dos ícones disponibilizados na tabela [Banco de Questões](#Banco de Questões), opções com ações sobre os registros existentes em banco, segue exemplos abaixo:

+ [Preview](#Preview)
+ [Editar](#Editar)
+ [Ativar/Inativar](#Ativar/Inativar)
+ [Histórico](#Histórico)

Imagem de exemplo:

![](.\Imagens\Questao_Banco_02.jpg)



#### Preview

**Comportamentos:**

+ Tooltip: O sistema deverá exibir a mensagem "Preview".
+ Ao acionar o botão *Preview* o sistema deverá abrir um modal com as informações contidas no registro da questão, segue exemplo de modelo:

![](.\Imagens\Questao_Banco_Preview_01.jpg)

Ao acionar o botão **X - (1)** o sistema deverá fechar o modal.



#### Editar

**Comportamentos:**

+ Tooltip: O sistema deverá exibir a mensagem "Editar"
+ Ao acionar o botão Editar o sistema deverá exibir o modal de confirmação para que o usuário possa inserir o motivo da solicitação de edição da questão, segue exemplo abaixo:

![](.\Imagens\Questao_Banco_Editar_01.jpg)

Ao acionar o botão **Cancelar - (1)** o sistema deverá fechar o modal.

Ao acionar o botão **Avançar - (2)** o sistema deverá validar a existência de conteúdo no campo motivo e então seguir para a tela de edição conforme imagem abaixo:

![](.\Imagens\Questao_Banco_Editar_02.jpg)

O título **Editar Questão - (1)** será a única alteração em relação a tela utilizada em uma nova questão. Para maiores informações sobre a tela favor consultar tópico [Nova Questão](#Nova Questão).



#### Ativar/Inativar

Abaixo serão mencionados os comportamentos referente aos botões de Ativar/Inativar uma questão, seguem tratativas:

|             Botão              | Ação                 | Status da Questão | Tooltip  | Link                  |
| :----------------------------: | -------------------- | ----------------- | -------- | --------------------- |
|   ![](./Imagens/Botão V.png)   | Ativar uma questão   | Inativo           | Ativar   | [Ativar](#Ativar)     |
| ![](./Imagens SVG/Botão X.svg) | Inativar uma questão | Ativo             | Inativar | [Inativar](#Inativar) |



##### Ativar

Ao acionar o **Botão Ativar - (V)** o sistema deverá exibir o modal de confirmação para que o usuário possa inserir o motivo da solicitação de ativação da questão, segue exemplo abaixo:

![](.\Imagens\Questao_Banco_Ativo-Inativo_02.jpg)

Ao acionar o botão **Cancelar - (1)** o sistema deverá fechar o modal e voltar a tela [Banco de Questões](#Banco de Questões) sem realizar alterações no registro.

Ao acionar o botão **Salvar - (2)** o sistema deverá validar a existência de conteúdo no campo motivo e então realizar as ações a seguir:

+ Alterar status do registro para Ativo;
+ Alterar ícone de ação Ativar/Inativar para **Botão Inativar - (X)**;



##### Inativar

Ao acionar o **Botão Inativar -  (X)** o sistema deverá exibir o modal de confirmação para que o usuário possa inserir o motivo da inativação da questão, segue exemplo abaixo:

![](.\Imagens\Questao_Banco_Ativo-Inativo_03.jpg)

Ao acionar o botão **Cancelar - (1)** o sistema deverá fechar o modal e voltar a tela [Banco de Questões](#Banco de Questões) sem realizar alterações no registro.

Ao acionar o botão **Salvar - (2)** o sistema deverá validar a existência de conteúdo no campo motivo e então realizar as ações a seguir:

- Alterar status do registro para Inativo;
- Alterar ícone de ação Ativar/Inativar para **Botão Ativar -  (V)**;



#### Histórico

**Comportamentos:**

- Tooltip: O sistema deverá exibir a mensagem "Histórico".
- Ao acionar o botão *Histórico* o sistema deverá exibir um modal com as informações contidas no registro da questão, segue exemplo de modelo:

![](.\Imagens\Questao_Banco_Historico_01.jpg)



Tabela com detalhes dos campos acima:

| Núm  | Campo      | Tipo      | Observação                                                   |
| :--: | :--------- | --------- | :----------------------------------------------------------- |
|  01  | Histórico  | Text      | Título do modal.                                             |
|  02  | X          | Button    | Fechar o modal e voltar a tela [Banco de Questões](#Banco de Questões). |
|  03  | Cabeçalho  | Text      | Informações a respeito da questão que está sendo consultada. |
|  04  | Data       | Date      | Data e hora de alteração do registro.                        |
|  05  | Usuário    | Text      | Usuário que realizou a alteração no registro.                |
|  06  | Status     | Text      | Status do registro.                                          |
|  07  | Observação | Text      | Texto referente a observação inserida no momento de realizar uma alteração de status ou edição da questão. |
|  08  | Scroll     | Scrollbar | Utilização de scroll caso exista mais de 5 registros no histórico. |




## Regras de Negócios

### RN1
#### Opções Dropdown

Regra destinada a definição das opções que deverão ser exibidas nos menus *dropdown* existentes neste documento.

**Campos e opções disponíveis:**

+ `Selecione o departamento da questão...` : Recursos Humanos; Farol;
+ `Selecione o tipo da questão...` : Múltipla Escolha; Seleção Única; Dissertativa.
+ `Selecione a(s) tag(s) da questão...` :
  + Frontend (HTML, CSS, Javascript)
    Vue
    Angular
    React
    Android
    iOS
    React Native
    Java
    Delphi
    .NET
    PHP
    Banco de dados
    Português
    Matemática
    Inglês
    Raciocínio Lógico
    Fit Cultural
    Comportamental
    Outros
+ `Selecione o nível da questão...` : Fácil; Médio; Difícil.



### RN2
#### Botão Limpar Filtro

O botão terá a ação de limpar o(s) filtro(s) solicitado(s), seguem observações quanto as regras de funcionamento:

- O botão ficará disponível para acionamento apenas quando o usuário selecionar ou inserir informações nos campos de filtragem;
- Limpar todos os filtros que tiverem em execução;
- Limpar todos os campos que tiverem informações inseridas;



### RN3

#### Botão Aplicar Filtro

**Comportamentos e Funções:**

+ O botão deverá ficar desabilitado quando nenhum campo for preenchido ou selecionado;
+ Ao acionar o botão Aplicar o sistema deverá filtrar a tabela [Banco de Questões](#Banco de Questões) em busca dos filtros solicitados.

+ Ao acionar o botão o sistema deverá exibir um [*Loading*](#RN11) até que a ação seja concluída, evitando assim o acionamento sequencial;
+ Caso o filtro realizado não retorne informações, o sistema deverá exibir a tabela [Banco de Questões](#Banco de Questões) sem registros (Consultar o tópico mencionado anteriormente para apresentação de tabela sem conteúdo); 



### RN4

#### Tabela Banco de Questões

A tabela Banco de Questões deverá exibir todos os registros de questões existentes no banco, segue abaixo detalhes dos campos existentes.

| Campo  | Tipo   |  Mascara  | Observação                                                   |
| ------ | ------ | :-------: | ------------------------------------------------------------ |
| Código | Número | 5 dígitos | Código da Questão, campo com geração automática de número sequencial. |
| Data   | Date   | dd/mm/aa  | Data de registro da questão, mascara utilizada: dd/mm/aa.    |
| Nome   | Text   |     -     | Nome da questão.                                             |
| Tipo   | Text   |     -     | Tipo da questão.                                             |
| Tag    | Tag    |     -     | Tag(s) referente ao registro.                                |
| Nível  | Text   |     -     | Nível da questão.                                            |
| Status | Text   |     -     | Status da questão.                                           |



### RN5

#### Botão Preview Nova Questão

**Comportamentos**:

+ Desabilitar botão:
  + O sistema deverá exibir o botão desabilitado por default;
+ Habilitar botão:
  + O sistema deverá habilitar o botão para acionamento somente quando os campos obrigatórios contidos no formulário de [Nova Questão](#Nova Questão) estiverem sido preenchidos.
+ Ao acionar o botão *Preview* o sistema deverá direcionar o usuário a tela de exibição das informações inseridas no formulário da tela [Nova Questão](#Nova Questão).



Exemplo de *preview* das questões do tipo Seleção Única com *RadioButton*:

![](.\Imagens\Questao_Nova_Preview_01.jpg)



Tabela com informações dos campos acima:

| Núm  | Campo   | Tipo   | Observação                                                |
| ---- | ------- | ------ | --------------------------------------------------------- |
| 01   | Título  | Text   | **Texto**: Preview de Questões                            |
| 02   | Preview | View   | Exibição das informações contidas no registro da questão. |
| 03   | Voltar  | Button | Voltar a [tela anterior](#Banco de Questões).             |



Exemplo de *preview* das questões de Múltipla Escolha com *CheckBox*:

![](.\Imagens\Questao_Nova_Preview_02.jpg)



Exemplo de *preview* das questões do tipo Dissertativas:

![](.\Imagens\Questao_Nova_Preview_03.jpg)



### RN6

#### Botão Salvar

**Comportamentos**:

+ O botão Salvar por ***default*** será exibido em modo desabilitado, somente quando o usuário preencher todos os campos obrigatórios contidos no formulário de [Nova Questão](#Nova Questão) então o sistema deverá habilitar o botão para acionamento.
+ Ao acionar o botão Salvar o sistema deverá exibir a tela de [*Loading*](#RN11) até que o formulário em questão seja validado e salvo em banco de dados, então deverá finalizar o processo com a apresentação da [Mensagem de Sucesso](#RN12).
+ Em casos de falha na validação de campos obrigatórios faltantes ou regras não atendidas então deverá exibir a [Mensagem de Validação](#RN17).



### RN7

#### Botão Adicionar nova alternativa

Ao acionar o botão **(+) Adicionar nova alternativa** o sistema deverá acrescentar outra alternativa seguindo o padrão mencionado abaixo.

**Regras:**

+ O sistema deverá limitar a inserção de novas alternativas em no máximo: 20 (Vinte opções);
+ O sistema deverá limitar a remoção de alternativas, favor verificar [RN9](#RN9) para maiores detalhes sobre exclusões;



### RN8

#### Alternativa Correta/Errada

Para a utilização dos botões *Alternativa Correta* e *Alternativa Errada* o sistema deverá validar algumas informações necessárias para a conclusão do processo de [Nova Questão](#Nova Questão).

**Comportamentos:**

+ Por *default* ao inserir uma nova alternativa o ícone deverá ser exibido em modo *Alternativa Errada*;
+ Questões de ***Múltipla Escolha***:
  + Por *default* o sistema deverá gerar uma nova questão com valor de alternativas como *Alternativa Errada*.
  + O sistema deverá liberar a opção de selecionar mais de uma alternativa como *Alternativa Correta*.
  + Será necessário ao menos uma alternativa correta para salvar a questão.
+ Questões de ***Seleção Única***: O sistema deverá bloquear a opção de selecionar mais de uma *Alternativa Correta*, também deverá utilizar a regra de *Radiobutton* onde o acionamento de um botão para Alternativa Correta automaticamente troca o estado do outro botão com o mesmo status para *Alternativa Errada*.

Imagem de exemplo:

![](.\Imagens\Questao_Nova_Multipla_02.jpg)



### RN9

#### Botão Excluir

O sistema deverá validar a existência de alternativas para a exclusão e visualização do botão em questão, seguem detalhes:

**Comportamentos:**

+ Habilitar botão: O sistema deverá exibir o botão somente quando houver mais de duas alternativas por questão;
+ Desabilitar botão: O sistema deverá ocultar o botão quando houver somente duas alternativas por questão;
+ A exclusão da alternativa deverá eliminar todo o registro contido nela;



Exemplo de questão com 3 alternativas:

![](.\Imagens\Questao_NovaAlternativa_01.jpg)

Exemplo de questão com 2 alternativas:

![](.\Imagens\Questao_NovaAlternativa_02.png)



### RN10

#### Peso da Alternativa

A função do campo *Selecione o peso da alternativa* será de determinar um valor especifico para  tal registro, valor este que deverá ser utilizado em cálculo de notas, seguem tratativas necessárias:

+ O sistema deverá habilitar o campo quando:
  
  + O tipo da questão for igual a [Múltipla Escolha](#Múltipla Escolha);
  + Houver mais de uma ["alternativa correta"](#RN8) na questão;
  
+ O sistema deverá desabilitar o campo quando:

  + O tipo da questão for diferente de [Múltipla Escolha](#Múltipla Escolha);
  + A alternativa for uma opção ["alternativa errada"](#RN8);
  + Houver apenas uma "[alternativa correta](#RN8)" na questão;

+ Opções de seleção:
  
  + Peso 1; Peso 2; Peso 3; Peso 4; Peso 5.
  
  

Exemplo de imagem para questões de múltipla escolha com mais de uma alternativa correta:

![](.\Imagens\Questao_PesoAlternativa.jpg)



### RN11

#### Loading

Esta regra é destinada ao comportamento e especificação do indicador de *loading* exibido quando uma ação é requisitada pelo sistema.

+ O indicador deverá ser exibido no topo da aplicação.

Sugestão de código para implementação: [Vuetify Loading](https://vuetifyjs.com/en/components/inputs#loading)

![](.\Imagens\Msg_Loading_01.jpg)



### RN12

#### Mensagem de Sucesso

Esta regra é destinada ao comportamento e especificação da mensagem de sucesso exibida quando um formulário é salvo no sistema.

+ A mensagem deverá ser exibida no topo da aplicação.

Exemplo:

![](.\Imagens\Msg_Success_01.jpg)



### RN13

#### Erro de Servidor

Esta regra é destinada ao comportamento e especificação da mensagem de erro exibida quando uma ação é interrompida no sistema por problemas com servidor.

- A mensagem deverá ser exibida no topo da página.

Imagem de exemplo:

![](.\Imagens\Msg_Error_01.jpg)



### RN14

#### Checkbox para justificativa

**Comportamentos:**

+ Exibir campo:
  + Caso o usuário selecione o [tipo da questão](#Tipos de Questões) como Múltipla Escolha ou Seleção Única;

+ Ocultar campo:
  + Caso o usuário selecione o [tipo da questão](#Tipos de Questões) como Dissertativa;

+ Será obrigatório o candidato responder a justificativa caso ela exista na questão.



### RN15

#### Botão Voltar

O botão Voltar existente na tela Nova Questão terá a função de exibir o modal para confirmação do cancelamento de geração de questão, segue detalhes abaixo:

+ O modal será exibido somente quando existir conteúdo no formulário, caso contrário sua ação será de retornar a tela [Banco de Questões](#Banco de Questões) sem exibir nada.

- Caso exista conteúdo no formulário e o usuário acione o botão Voltar, o sistema deverá exibir o modal abaixo:

![](./Imagens/Modal Aviso.png)

Ao acionar o botão **Cancelar - (1)** o sistema deverá fechar o modal e voltar a tela Nova Questão.

Ao acionar o botão **Sim - (2)** o sistema deverá ignorar as informações inseridas no formulário e exibir a tela [Banco de Questões](#Banco de Questões).



### RN16

#### Tecla ESQ

O objetivo dessa regra de negócio é definir a tecla ESQ como sendo um atalho para o fechamentos dos modais existentes neste documento, onde deverá seguir os seguintes comportamentos:

**Comportamentos:**

- Ao acionar a tecla ESQ o sistema deverá fechar o modal e direcionar o usuário a tela anterior;
- O sistema deverá fechar o modal e não realizar alterações no formulário;



### RN16

#### Mensagem de Validação

Validação de campos obrigatórios:

![](.\Imagens\Msg_Validacao_01.png)



Validação de campos obrigatórios e *Alternativa Correta* na questão:

![](.\Imagens\Msg_Validacao_02.png)



# Testes de Aceitação do Usuário

## Critério de Aceitação

O sistema será considerado como concluído somente após a validação e aprovação dos tópicos mencionados acima, é de extrema importância a realização dos itens a seguir:

- Seguir os padrões de layout especificado neste documento;
- Seguir a disposição dos objetos conforme mencionados nos tópicos acima, visto que os padrões de usabilidade seguem boas práticas de mercado;



## Cenários

- Geração de Questões:

**Dado** que eu esteja na página [Nova Questão](#Nova Questão) 
		E eu preencha os dados para uma nova questão
**Quando** eu acionar o botão Voltar,
**Então** deverá ignorar os dados contidos no formulário atual
		E voltar a tela [Banco de Questões](#Banco de Questões).



- Ocultar Peso da Alternativa:

**Dado** que eu esteja na página [Nova Questão](#Nova Questão),
**Quando** eu acionar o botão [Alternativa Correta](#RN8) em apenas uma alternativa
**Então** deverá ocultar o campo [Peso da Alternativa](#RN10).



- *Checkbox* para Justificativa:

**Dado** que eu esteja na página [Nova Questão](#Nova Questão),
**Quando** eu escolher o tipo de questão como [Múltipla escolha](#Múltipla Escolha),
**Então** deverá exibir o [*checkbox* para justificativa](#RN14) dando a opção do usuário escolher adicionar ou não o campo em questão.



- Exibir Justificativa:

**Dado** que eu esteja na página [Nova Questão](#Nova Questão),
**Quando** eu acionar o [*Checkbox* para Justificativa](#RN14),
**Então** deverá exibir o campo [justificativa](#Justificativa) apenas no momento de visualizar e responder a questão.




# Termo de Compromisso

Estou ciente que todas as implementações citadas neste  documento estão condizentes com a necessidade da empresa, sendo assim,  reconheço que futuras alterações de assuntos não mencionados neste documento  serão consideradas como uma nova alteração não prevista, gerando uma nova  análise e levantamento, bem como a descrição de um novo documento de  Especificação de Requisito.

 

I am aware  that all implementations mentioned in this document are consistent with the  company's need, so that future changes to recognize issues not listed in this  document will be considered as a new change not provided, generating a new  survey and analysis, as well as the description of a new Requirement  Specification document.



# Aprovação

Data limite de aprovação segundo o plano de projeto: **[Data Limite]**

| Nome          | Data | Assinatura |
| ------------- | ---- | ---------- |
| Cristiane Abe |      |            |