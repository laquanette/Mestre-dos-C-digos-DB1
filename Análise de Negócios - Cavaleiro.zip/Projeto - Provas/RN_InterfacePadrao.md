| ![](.\Imagens\Logo_DB1.png) |       RN - Interface       | ![](.\Imagens\Logo_Prova.png) |
| :-------------------------: | :------------------------: | :---------------------------: |
|       **ID Req:** 006       | **ID Projeto:** API_Provas | **Nome Projeto:** Provas DB1  |

[TOC]

# Introdução #

O presente documento tem como objetivo apresentar os padrões de interface para o sistema de Provas que deverão ser seguidos e atualizados, caso tenha alguma alteração durante o desenvolvimento do projeto. 

Este documento contém padrões, bem como informações para o desenvolvimento do portal Web.



# Elementos da Interface

## Header

Na *header* será apresentado conforme padrão abaixo, sempre marcando a tela em exibição. 

|       Header Padrão       |
| :-----------------------: |
| ![](./Imagens/Header.png) |



## Cores

|            Cores             |
| :--------------------------: |
| ![](Imagens/PaletaCores.png) |



## Fontes

- Open Sans;



## Logo

|       Logo DB1 Group        |
| :-------------------------: |
| ![](./Imagens/Logo_DB1.png) |



## Componentes de Tabelas

### Botões


|          Botões           |
| :-----------------------: |
| ![](./Imagens/Botoes.png) |





### Ícones

|          Ícones          |
| :----------------------: |
| ![](./Imagens/Icons.png) |



### Tag's

|         Tag's          |
| :--------------------: |
| ![](./Imagens/Tag.png) |



### Dropdown

Este componente permite a digitação no campo de busca para auxílio na seleção do dado.

|          Dropdown          |
| :-------------------------------: |
| ![](./Imagens/Dropdown.png) |



### Modal
### Modal de Ação

|        Modal Padrão        |
| :------------------------: |
| ![](./Imagens/Modal01.png) |

### Modal Alerta

|        Modal Padrão        |
| :------------------------: |
| ![](./Imagens/Modal02.png) |
### Modal de Visualização

|        Modal Padrão        |
| :------------------------: |
| ![](./Imagens/Modal03.png) |



### Estados de Sucesso para Elementos

Caso precise evidenciar o sucesso da ação em tela, deverão ser exibidos centralizados no topo da página.

Segue abaixo os modelos:

| Estados de Sucesso - Formulário Salvo |
| :-----------------------------------: |
|       ![](./Imagens/Msg01.png)        |

| Estados de Sucesso - Formulário Finalizado |
| :----------------------------------------: |
|          ![](./Imagens/Msg02.png)          |



## Layout de Alertas

Os alertas deverão ser exibidos centralizados no topo da página.

Segue abaixo os modelos:

|       Alerta de Falha na Conexão       |
| :----------------------------: |
| ![](./Imagens/Alerta01.png) |

|       Alerta de Conclusão 01       |
| :----------------------------: |
| ![](./Imagens/Alerta02.png) |

|       Alerta de Conclusão 02       |
| :----------------------------: |
| ![](./Imagens/Alerta03.png) |


