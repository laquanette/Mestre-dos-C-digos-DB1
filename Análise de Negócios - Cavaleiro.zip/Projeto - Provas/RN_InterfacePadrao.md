| ![](.\Imagens\Logo_DB1.png) |       RN - Interface       | ![](.\Imagens\Logo_Prova.png) |
| :-------------------------: | :------------------------: | :---------------------------: |
|       **ID Req:** 006       | **ID Projeto:** API_Provas | **Nome Projeto:** Provas DB1  |

[TOC]

# Introdução #

O presente documento tem como objetivo apresentar os padrões de interface para o sistema de Provas que deverão ser seguidos e atualizados, caso tenha alguma alteração durante o desenvolvimento do projeto. 

Este documento contém padrões, bem como informações para o desenvolvimento do portal Web.



# Elementos da Interface

## Fontes

- Família: Open Sans.
- Tipo: Light, Regular e Bold.
- Tamanho: 31px / 40px



## Header

Na *header* será apresentado conforme padrão abaixo, sempre marcando a tela em exibição. 

|       Header Padrão       |
| :-----------------------: |
| ![](./Imagens/Header.png) |

- Cor:
  - Fundo do header: #006D99



## Logo

|       Logo DB1 Group        |
| :-------------------------: |
| ![](./Imagens/Logo_DB1.png) |

- Cor:
  - Desenho: #B93732
  - Fonte: #6C6B70



## Componentes de Tabelas

### Botões


|          Botões           |
| :-----------------------: |
| ![](./Imagens/Botoes.png) |

- Cor:
  - Fundo do botão: #00335E
  - Letra botão preview: #006D99
  - Letra dos botões de fundo branco: #6C6B70



### Ícones

|          Ícones          |
| :----------------------: |
| ![](./Imagens/Icons.png) |



### Tag's

|         Tag's          |
| :--------------------: |
| ![](./Imagens/Tag.png) |



### Dropdown

Este componente permite a digitação no campo de busca para auxílio na seleção do dado.

|          Dropdown          |
| :-------------------------------: |
| ![](./Imagens/Dropdown.png) |



### Modal
### Modal de Ação

|        Modal Padrão        |
| :------------------------: |
| ![](./Imagens/Modal01.png) |

### Modal Alerta

|        Modal Padrão        |
| :------------------------: |
| ![](./Imagens/Modal02.png) |
### Modal de Visualização

|        Modal Padrão        |
| :------------------------: |
| ![](./Imagens/Modal03.png) |



### Estados de Sucesso para Elementos

Caso precise evidenciar o sucesso da ação em tela, deverão ser exibidos centralizados no topo da página.

Segue abaixo os modelos:

| Estados de Sucesso - Formulário Salvo |
| :-----------------------------------: |
|       ![](./Imagens/Msg01.png)        |

| Estados de Sucesso - Formulário Finalizado |
| :----------------------------------------: |
|          ![](./Imagens/Msg02.png)          |

- Detalhes:
  - Cor de Fundo: #D4EDDA
  - Cor da Letra: #155724
    - Tamanho: 18px
    - Fonte: Open Sans
    - Tipo: Regular
  - Cor do Ícone: #155724
    - Tamanho: 30 x 30 px

## Layout de Alertas

Os alertas deverão ser exibidos centralizados no topo da página.

Segue abaixo os modelos:

|       Alerta de Falha na Conexão       |
| :----------------------------: |
| ![](./Imagens/Alerta01.png) |

Detalhes:

- Cor de Fundo: #FFF3CD
- Cor da Letra: #C58814
  - Tamanho: 14px
  - Fonte: Open Sans
  - Tipo: Semi Bold
- Cor do Ícone: #C58814
  - Tamanho: 30 x 26 px



|       Alerta de Conclusão 01       |
| :----------------------------: |
| ![](./Imagens/Alerta02.png) |

|       Alerta de Conclusão 02       |
| :----------------------------: |
| ![](./Imagens/Alerta03.png) |

Detalhes:

- Cor de Fundo: #FFCDCD
- Cor da Letra: #E03939
  - Tamanho: 14px
  - Fonte: Open Sans
  - Tipo: Semi Bold
- Cor do Ícone: #E03939
  - Tamanho: 30 x 26 px