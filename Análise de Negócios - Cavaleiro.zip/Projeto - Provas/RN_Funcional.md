| ![](.\Imagens\Logo_DB1.png) |       RN - Funcional       | ![](.\Imagens\Logo_Prova.png) |
| :-------------------------: | :------------------------: | :---------------------------: |
|       **ID Req:** 005       | **ID Projeto:** API_Provas | **Nome Projeto:** Provas DB1  |

[TOC]

# Artefatos Relacionados #

| Artefatos        | Título                                           |
| :--------------- | :----------------------------------------------- |
| Interface Padrão | [RN_InterfacePadrao.md](./RN_InterfacePadrao.md) |



# Desempenho #

## Volume de Utilização ##

| Dados                        | Volume de Lançamentos (DIA) |
| ---------------------------- | :-------------------------- |
| Geração de Provas e Questões | 120                         |
| Acessos Simultâneos          | 50                          |



# Operacional #

- **Disponibilidade**: O sistema deverá ter uma disponibilidade 24/7. Vinte e quatro horas por dia e sete dias por semana.
- **Escalabilidade**: O sistema será escalável, tendo como futuro acesso de 100 usuários simultâneos;
- **Segurança**: 
  - O método de autenticação e segurança utilizado Auth0;
- **Instabilidade**: 
  - No caso de a Aplicação identificar que há uma falha de conexão (entre o início e o fim de uma determinada requisição para o servidor), então deverá:
    - Ser apresentada a mensagem para o usuário;
    - Nenhum dado deverá ser persistido;
    - Observação: As exceções deverão ser tratadas pontualmente no documento de requisito funcional.
- **Compatibilidade**: 
  - A versão 1.0 deste sistema deverá ser compatível com os navegadores: 
    - Chrome: Versão 5.4.6 até 10.4.6
    - Firefox: Versão 2 até 8
    - Edge: Versão 5.3.2 até 9.2.1
    - Internet Explorer: Versão 2.6.2 até 7.4.1
  - Navegadores fora dos padrões estipulados acima deverão ser alertados de que o funcionamento desta ferramenta é melhor aplicado em outra versão do navegador;
  - Em relação a responsividade do layout deverá ocorrer dentro dos seguintes padrões:
    - Desktop: 1440 x 1024 até 1500 x 1000
    - Tablet: 768 x 1024 até 1368 x 912;
    - Celular: Não suportado
- **Usabilidade**: A interface deve se dimensionar automaticamente independente das configurações de monitor utilizado.



# Desenvolvimento #

- **Flexibilidade**: Este produto deverá ter flexibilidade em ser alterado, uma vez que ele será evoluído.
  - Sua flexibilização poderá ocorrer dentro do contexto de ferramenta para produção de provas e questões, não sendo possível alteração em sua estrutura de negócio e escopo;
- **Reusabilidade**: Deverá ser aplicado este conceito na construção de componente para serem reaproveitados em qualquer funcionalidade;



# Tratamento de dados #

## Datas e Horas

* O formato padrão de data que o sistema deverá seguir é o: DD/MM/AA.

* O formato padrão de horas que o sistema deverá seguir é o: HH:MM.



## Máscaras ##

- **CÓDIGO**: 99999;
- **E-mail**: xyz@xyz.com.br;
