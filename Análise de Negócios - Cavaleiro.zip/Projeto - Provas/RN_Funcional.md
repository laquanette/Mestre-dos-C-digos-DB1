| ![](.\Imagens\Logo_DB1.png) |       RN - Funcional       | ![](.\Imagens\Logo_Prova.png) |
| :-------------------------: | :------------------------: | :---------------------------: |
|       **ID Req:** 005       | **ID Projeto:** API_Provas | **Nome Projeto:** Provas DB1  |

[TOC]

# Artefatos Relacionados #

| Artefatos        | Título                                           |
| :--------------- | :----------------------------------------------- |
| Interface Padrão | [RN_InterfacePadrao.md](./RN_InterfacePadrao.md) |



# Desempenho #

## Volume de Utilização ##

| Dados                        | Volume de Lançamentos (DIA) |
| ---------------------------- | :-------------------------- |
| Geração de Provas e Questões | 120                         |
| Acessos Simultâneos          | 50                          |



# Operacional #

- **Disponibilidade**: O sistema deverá ter uma disponibilidade 24/7. Vinte e quatro horas por dia e sete dias por semana.
- **Escalabilidade**: O sistema será escalável, tendo como futuro acesso de 100 usuários simultâneos;
- **Segurança**: 
  - O meto de autenticação e segurança utilizado Auth0;
- **Instabilidade**: 
  - No caso de a Aplicação identificar que há uma falha de conexão (entre o início e o fim de uma determinada requisição para o servidor), então deverá:
    - Ser apresentada a mensagem para o usuário;
    - Nenhum dado deverá ser persistido;
    - Observação: As exceções deverão ser tratadas pontualmente no documento de requisito funcional.
- **Compatibilidade**: 
  - Deverá ser compatível com os navegadores: Chrome, Firefox e Edge atualizados;
- **Usabilidade**: A interface deve se dimensionar automaticamente independente das configurações de monitor utilizado.



# Desenvolvimento #

- **Flexibilidade**: Este produto deverá ter flexibilidade em ser alterado, uma vez que ele será evoluído.
- **Reusabilidade**: Deverá ser aplicado este conceito na construção de componente para serem reaproveitados em qualquer funcionalidade;



# Tratamento de dados #

## Datas e Horas

* O formato padrão de data que o sistema deverá seguir é o: DD/MM/AA.

* O formato padrão de horas que o sistema deverá seguir é o: HH:MM.



## Máscaras ##

- **CÓDIGO**: 99999;
- **E-mail**: xyz@xyz.com.br;
