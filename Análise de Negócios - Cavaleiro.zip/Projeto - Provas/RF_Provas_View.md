| ![alt text](./Imagens/Logo_DB1.png) | Requisito - Apresentação de Prova FIT |  ![](./Imagens/Logo_prova.png)  |
| :---------------------------------: | :-----------------------------------: | :-----------------------------: |
|           **ID Req:** 004           |     **ID Projeto:** API_Prova_FIT     | **Nome Projeto:** API Prova FIT |



# Sumário

[TOC]

# Informações

## Edições

| **Versão** | **Data**   | **Autor**         | **Comentários**                 |
| ---------- | ---------- | ----------------- | ------------------------------- |
| 1.0        | 09/08/2019 | Renato Laquanette | Criação do documento            |
| 1.1        | 09/09/2019 | Renato Laquanette | Atualização de Layout           |
| 1.2        | 27/11/2019 | Renato Laquanette | Atualização de Layout DB1 Group |



# Análise de Processos

Atualmente quando um candidato se inscreve em uma vaga no site da DB1, é encaminhado uma avaliação de FIT cultural onde deverá ser respondida e posteriormente corrigida automaticamente pelo sistema RBD (Sistema de integração RB x RD).

Desta forma, quando um candidato é rejeitado no sistema, o departamento de Recursos Humanos não tem a disponibilidade dos resultados da prova, impedindo a análise e posterior tomada de decisões em relação aos resultados abaixo da nota de corte do sistema.

Mediante os fatos citados acima, este projeto tem como objetivo realizar a apresentação dos resultados da prova de FIT Cultural em página web, disponibilizando o link da página dentro do perfil do candidato no sistema Recruiter Box.

Fluxograma do processo:

![](.\Imagens\Fluxo Prova FIT.png)



## Premissa

+ O sistema Recruiter Box deverá estar em operação;



## Restrições

+ Mudanças nas API's do RBD podem impactar na troca de informações entre os sistemas;




# História de Usuário

Como membro do Departamento de Recursos Humanos da DB1 Global Software, desejo acessar a prova de Fit Cultural dos candidatos existentes no Recruiter Box, podendo assim analisar as questões respondidas e tomar as decisões necessárias.



#  Requisitos Funcionais

Conforme descrito em [Análise de Processos](#Análise de Processos), esta funcionalidade contempla os seguintes itens abaixo:

+ **Atividades:**

  + [Inserção do link da prova no Recruiter Box](#Link de acesso);
  + [Requisição de dados no RBD](#Requisição de dados no RBD);
  + [Apresentação da prova FIT Cultural em página web](#View prova FIT);

  

+ Os protótipos apresentados neste documento estão disponíveis em: [Protótipo Prova](https://www.figma.com/proto/cUjGaOYkzcOFxNV3H9kd7T/View-Prova-FIT?node-id=63%3A3&viewport=-138%2C228%2C0.3976004421710968&scaling=min-zoom)



## Link de acesso

Para que seja possível acessar a visualização do resultado da prova dentro do sistema RecruiterBox, um link será disponibilizado no ***Profile*** do candidato, segue abaixo exemplo do acesso:

![](.\Imagens\Acesso RecruiterBox 03.png)



Tabela com detalhes dos campos mencionados acima:

| Núm. |   Campo   | Descrição                                                    |
| :--: | :-------: | ------------------------------------------------------------ |
|  01  |  Profile  | Aba contendo os dados do candidato.                          |
|  02  | Resultado | Campo para exibição do resultado. **Texto:** URL para visualização - Prova de FIT Cultural: "Link" |



**Erros relacionados a exibição da prova:**

Caso o sistema apresente problemas no momento de exibir a prova através do link de acesso, a mensagem especificada na [RN2](#RN2) deverá ser exibida.



## Requisição de dados no RBD

O sistema deverá requisitar os dados abaixo no banco de dados do RBD.

+ ``Data`` : Data em que o candidato respondeu a prova de FIT Cultural;
+ ``Candidato`` : Nome do candidato;
+ ``E-mail`` : E-mail do candidato;
+ ``Perguntas`` : Perguntas existentes na prova de FIT Cultural;
+ ``Respostas`` : Respostas referente as perguntas existentes na prova de FIT Cultural;
  + O sistema deverá exibir todas as alternativas existentes para resposta, destacando apenas a correta.



## View prova FIT

Para que os colaboradores do departamento de recursos humanos consiga visualizar a prova de FIT Cultural, o sistema deverá apresentar uma página web contendo o espelho da prova que o candidato respondeu.

![](.\Imagens\Provas_View_01.jpg)

Tabela com detalhes dos campos mencionados acima:

| Núm. |   Campo   |   Tipo    | Descrição                                                    |
| :--: | :-------: | :-------: | ------------------------------------------------------------ |
|  01  | Logo DB1  |   Logo    | Logo DB1 Group.                                              |
|  02  |  Título   |   Text    | Título da Prova. **Texto:** Prova de FIT Cultural            |
|  03  |  Avatar   | Icon+Text | Avatar e nome do colaborador.                                |
|  04  |   Data    |   Date    | Data de resolução da prova. **Mascara:** dd/mm/aaaa          |
|  05  | Candidato |   Text    | Nome do candidato.                                           |
|  06  |  E-mail   |   Text    | E-mail do candidato.                                         |
|  07  | Questões: |   Text    | Nome da tabela.                                              |
|  08  | Enunciado |   Text    | Enunciado das questões existentes na prova de FIT Cultural.  |
|  09  | Resposta  |   Text    | Respostas das questões existentes na prova de FIT Cultural. Vide [RN1](#RN1). |




## Regras de Negócios

### RN1

#### Respostas

Para que seja possível a análise e tomada de decisão quanto a questões com justificativa, será necessário efetuar algumas tratativas nas respostas das questões, são elas:

+ O sistema deverá apresentar todas as alternativas existentes na questão, marcando com **negrito** a alternativa que o usuário respondeu.
+ O sistema deverá apresentar as respostas conforme o tipo da questão existente na prova.



Exemplo de questão com justificativa:

![](.\Imagens\Provas_View_02.jpg)

**Justificativa - (1)** : Deverá ser exibida sempre que uma questão tiver o campo justificativa para resolução.



### RN2

#### Erro de Requisição

Este tópico descreve a forma de apresentação caso algum erro inesperado com o serviço de envio ao servidor ocorra. 

- A mensagem deverá ser exibida no topo da página.

Imagem de exemplo:

![](.\Imagens\Msg_Error_01.jpg)



# Testes de Aceitação do Usuário

## Critério de Aceitação

+ Os padrões de apresentação deverão seguir as regras e campos mencionados neste documento.
+ O sistema deverá exibir a mensagem de erro caso algum imprevisto com o servidor venha a ocorrer.




# Termo de Compromisso

Estou ciente que todas as implementações citadas neste  documento estão condizentes com a necessidade da empresa, sendo assim,  reconheço que futuras alterações de assuntos não mencionados neste documento  serão consideradas como uma nova alteração não prevista, gerando uma nova  análise e levantamento, bem como a descrição de um novo documento de  Especificação de Requisito.

 

I am aware  that all implementations mentioned in this document are consistent with the  company's need, so that future changes to recognize issues not listed in this  document will be considered as a new change not provided, generating a new  survey and analysis, as well as the description of a new Requirement  Specification document.



# Aprovação

Data limite de aprovação segundo o plano de projeto: **[Data Limite]**

| Nome                   | Data | Assinatura |
| ---------------------- | ---- | ---------- |
| Maiko Antonio da Cunha |      |            |